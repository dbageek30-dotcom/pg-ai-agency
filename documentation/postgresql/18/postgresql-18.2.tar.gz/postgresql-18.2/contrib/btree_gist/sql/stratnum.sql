-- test stratnum translation support func
SELECT gist_translate_cmptype_btree(7);
SELECT gist_translate_cmptype_btree(3);
